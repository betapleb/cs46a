public class LazyCritter extends Critter
{
    // instance variables - replace the example below with your own
    private boolean action;

    /**
     * Constructor for objects of class LazyCritter
     */
    public LazyCritter(double theWeight)
    {
        super(theWeight);
        action = true;
    }

    public void move(int steps)
    {
        if (action)
        {
            addHistory("eat");
            action = false;
        }
        else
        {
            addHistory("sleep");
            action = true;
        }
    }
}
