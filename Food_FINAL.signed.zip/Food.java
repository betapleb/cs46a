/**
 * Shows number of carbs in food
 */
public class Food extends Product
{
    private int carbs;
    private String description;
    private double price;

    /**
     * Constructor for objects of class Food
     * @param description of product
     * @param price of product
     * @param carbs in grams of the product
     */
    public Food (String description, double price, int carbs)
    {   
        super(description, price);
        this.price = price;
        this.description = description;
        this.carbs = carbs;

    }

    /**
     * sets the number of carbohydrates
     * @param grams number of grams
     */
    public void setCarbs(double grams)
    {
        carbs = (int)grams;
    }

    /**
     * gets the number of carbohydrates
     * @return number of carbs
     */
    public int getCarbs(){
        return carbs;
    }

    /**
     * tells if this Food is considered low carb
     * low carb <= 10 grams of carbohydrates. 
     * @return true if the Food has 10 or fewer carbs. Otherwise, return false.
     */
    public boolean isLowCarb(){
        if (carbs <= 10.0){
            return true;
        } else {
            return false;
        }
    }

    /**
     * overrides the getDescription method in Product class to also include the number of carbs.
     * Call the getDescription method in the super class and add the new information 
     * on the end. The return string will look like this: oatmeal carbs=8.3
     * @return string of food and its grams of carbs
     */
    public String getDescription(){
        super.getDescription();
        return description + "  carbs=" + getCarbs();
    }

}
