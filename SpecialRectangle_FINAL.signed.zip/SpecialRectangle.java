public class SpecialRectangle extends Rectangle
{

    private String paintColor;

    /**
     * Constructor for objects of class SpecialRectangle
     */
    public SpecialRectangle(int x, int y, int width, int height)
    {

        super(x,y,width,height); 
        Color SILVER = new Color(204,204,204);
        super.setColor(SILVER);
        paintColor = "silver";
    }

    /**
     * 2nd Constructor for objects of class SpecialRectangle
     */
    public SpecialRectangle(int x, int y, int width, int height, String paintColor)
    {
        super(x,y,width,height);

        if (paintColor.equals("vanilla")){
            Color VANILLA = new Color(255, 255, 248);
            setPaintColor(paintColor);
            super.setColor(VANILLA);
        }
        else if (paintColor.equals("blue_green"))
        {
            Color BLUE_GREEN = new Color(204, 255, 255);
            setPaintColor(paintColor);
            super.setColor(BLUE_GREEN);
        }
        else if (paintColor.equals("purple")){
            Color PURPLE = new Color(159, 0, 197);
            setPaintColor(paintColor);
            super.setColor(PURPLE);  
        }
        else if (paintColor.equals("burnt_orange")){

            Color BURNT_ORANGE = new Color (227, 117, 00);
            setPaintColor(paintColor);
            super.setColor(BURNT_ORANGE);
        }
        else {

            Color SILVER = new Color(204,204,204);
            setPaintColor(paintColor);
            super.setColor(SILVER);
        }

        /**
        if (paintColor != "vanilla" || paintColor != "blue_green" || paintColor != "purple"|| paintColor != "burnt_orange"){
        paintColor = "silver";
        }
        else if (paintColor == "vanilla"){
        Color VANILLA = new Color(255, 255, 248);
        super.setColor(VANILLA);
        }
        else if (paintColor == "blue_green"){
        Color BLUE_GREEN = new Color(204, 255, 255);
        super.setColor(BLUE_GREEN);
        }
        else if (paintColor == "purple"){
        Color PURPLE = new Color(159, 0, 197);
        super.setColor(PURPLE);  
        }
        else if (paintColor == "burnt_orange"){
        Color BURNT_ORANGE = new Color (227, 117, 00);
        super.setColor(BURNT_ORANGE);
        }
         */
    }

    public String getPaintColor()
    {
        return paintColor;
    }

    public void setPaintColor(String newColor)
    {
        if (!(newColor.equals("vanilla")) || 
        !(newColor.equals("blue_green")) || 
        !(newColor.equals("purple")) || 
        !(newColor.equals("burnt_orange")))
        {
            Color SILVER = new Color(204,204,204);
            paintColor = newColor;
            super.setColor(SILVER);
        }
        else {
            paintColor = newColor;
        }
    }

}
