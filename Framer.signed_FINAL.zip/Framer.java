
/**
 * make the first row of pixels red
 */
public class Framer
{
    public static void main (String args[])
    {
        Picture pic = new Picture();
        pic.load("oliver_bed.jpg");
        pic.draw();
        
        /**
        for (int y = 0; y <= pic.getHeight(); y++ )
        { // incrementing y but youre not doing anything with it.  going thru first for loop but not doing anything with it. you're doing work in the inner for loop.
           for (int x = 0; x < pic.getWidth(); x++)
           {
               Color red = new Color(255,0,0);
               pic.setColorAt(x, 0, red); 
           }
        }
        pic.draw();
        */
        
        double centerX = pic.getWidth() / 2;
        double centerY = pic.getHeight() / 2;
        double radius = pic.getHeight()*.4;
        
        for (int x = 0; x < pic.getWidth(); x++)
        {
            for (int y = 0; y < pic.getHeight(); y++)
            {
                double distance = Math.sqrt((centerX - x) * (centerX - x) + (centerY - y) * (centerY - y));
                if (distance > radius)
                {
                    pic.setColorAt(x, y, Color.BLACK);
                }
            }
        }
        
    }
}