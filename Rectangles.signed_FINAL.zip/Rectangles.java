import java.util.ArrayList;
/**
 * A class to manage rectangles
 */
public class Rectangles
{   
    //instance variable
    ArrayList<Rectangle> list = new ArrayList<Rectangle>();

    /**
     * constructor takes no parameters but initializes
     * the instance variable to an empty ArrayList
     */
    public Rectangles()
    {
        ArrayList<Rectangle> list = new ArrayList<Rectangle>();

    }

    /**
     * method to add rectangles to ArrayList
     * @param r the rectangle to be added to ArrayList
     */
    public void add(Rectangle r){
        list.add(r);
    }

    /**
     * swaps the element at index1 with the element at index2
     * If either index is out of bounds, do not change anything.
     * @param index1 item to swap with index2
     * @param index2 item to swap with index1
     */
    public void swap(int index1, int index2){
        if (index1 >= 0 && index2 >= 0 && index1 <= list.size()-1 && index2 <= list.size()-1){
            Rectangle first = list.get(index1);
            Rectangle second = list.get(index2);
            list.set(index2, first);
            list.set(index1, second);
        }

    }

    /**
     * gets the Rectangle with the largest area. 
     * If the Rectangles object is empty, return null
     * @return If more than one Rectangle has the same areas, return the first.  
     */
    public Rectangle largest(){
        if (list.isEmpty()){
            return null;
        } else {
            Rectangle largest = list.get(0); //rectangle at index 0 will always be largest in the beginning.
            double largestArea = 0;
            for(Rectangle r: list)  
            {
                double width = r.getWidth();
                double height = r.getHeight();
                double newArea = width+height;
                if(newArea > largestArea)
                {
                    largestArea = newArea;
                    largest = r;
                }

            }
            return largest;
        }

    }

    /**
     * does something
     * @return ArrayList
     */
    @Override
    public String toString()
    {
        return list.toString();
    }
}
