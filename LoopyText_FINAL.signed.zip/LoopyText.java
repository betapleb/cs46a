/**
 * Provides some methods to manipulate text
 * 
 */
public class LoopyText
{
    private String text;
    
    /**
     * Creates a LoopyText object with the given text
     * @param theText the text for this LoopyText
     */
    public LoopyText(String theText)
    {
        text = theText;
    }
    
    /**
     * gets a string consisting of every other character, starting with the character at index 0
     * @return string consisting of every other character
     */
    public String getEverySecondCharacter() {
    		String sentence ="";
    		for (int i = 0; i < text.length(); i+=2) {
    			sentence += text.charAt(i);
    		}
    		return sentence;
    }	
    
    /**
     * gets the number of upper case letters in the text
     * @return upper case letters
     */
    public int upperCaseCount() {
    		int count = 0;
    		for (int i = 0; i < text.length(); i++) {
    			if(Character.isUpperCase(text.charAt(i))) {
    				count++;
    			}
    		}
    		return count;
    }
    
    /**
     * returns a string consisting of the first character of every word in the string
     * @return first letter of every word
     */
    public String firstLetters() {
    		String firstLetterString = "";
    		String everyChar;
    		String veryFirstLetter = text.substring(0,1);
    		for (int i = 0; i < text.length(); i++) {
    			everyChar = text.substring(i, i+1); //goes thru every char
    			if (everyChar.equals(" ")) {		   //if there's a space
    				firstLetterString = firstLetterString + text.substring(i+1, i+2); //then, save the letter after the space. 
    			}
    		}
    		return veryFirstLetter+firstLetterString;
    }
}
