/**
 * Models a room at a beach resort
 */
public class ResortRoom
{

	public static final int OCEAN_SIDE = 0;
	public static final int STREET_SIDE = 1;
	public static final double EXTRA_PERSON = 100.00;
	private int occupants;
	private int type;
	/**
	 * initializes type and occupants variables
	 * @param type type of room
	 * @param numberOfOccupants number of guests per room
	 */
	public ResortRoom(int type, int numberOfOccupants) {
		
		if (numberOfOccupants <= 0) {
			occupants = 2;
		} else {
			occupants = numberOfOccupants;
		}
		
		this.type = type;
		if (this.type != OCEAN_SIDE && this.type != STREET_SIDE) {
			this.type = OCEAN_SIDE;
		}
		
	}
    
	/**
     * Gets the number of occupants in the room
     * @return the number of occupants in the room
     */
    public int getOccupants() 
    {
        return occupants;
    }
    
    /**
     * gets the cost of the specified room
     * @return the cost
     */
    public double getCost()
    {	
    		double cost=0;
    		if (this.type == OCEAN_SIDE) {
    			if(occupants<=2) {
    				cost = 250.00;
    			} else if(occupants==3 || occupants==4) {
    				cost = 370.00;
    			} else if(occupants>4){
    				cost = 370.00+(EXTRA_PERSON*((double)occupants-4.0));
    			}
    		} 
    		else {
    			if(occupants<=2) {
    				cost = 175.00;
    			} else if(occupants==3 || occupants==4){
    				cost = 260.00;
    			} else if(occupants>4){
    				cost = 260.00+(EXTRA_PERSON*((double)occupants-4.0));
    			}
    		}
		return cost;
    }
    
    /**
     * sets the number of occupants renting this ResortRoom
     * @param number change number of occupants
     */
    public void setOccupants(int number) {
    		occupants = number;
    		if (occupants <= 0) {
    			occupants = 2;
    		} else {
    			occupants = number;
    		}
    }
   
    /**
     * gets type of this room, either "ocean" or "street"
     * @return the type of room
     */
    public String getType() {
    		if (type==OCEAN_SIDE) {
    			return "ocean";
    		} else {
    			return "street";
    		}
    }
    
}
