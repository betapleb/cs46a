
import java.util.Arrays;
/**
 * Manages Rectangles
 */
public class RectanglesArray
{
    private Rectangle[] list;

    /**
     * takes an array of Rectangles as a parameter and initializes the instance variable with it.
     * @param myList creates empty Rectangle array
     */
    public RectanglesArray(Rectangle[] myList)
    {
        list = myList;
    }

    /**
     * finds the average area of a Rectangles in this array
     * @return averageArea returns the avg. area of all rectangles
     */
    public double averageArea(){
        double avg = 0;
        double count = 0;
        for (Rectangle p : list)
        {
            avg = avg + area(p);
            count++;
        }
        return avg/count;

    }

    /**
     * gets the Rectangle with the largest area
     * If more than one Rectangle has the same areas, return the first. 
     * @return Rectangle with the largest area
     */
    public Rectangle largest(){
        if (list.length == 0){
            return null;
        }
        Rectangle largest = list[0];
        double largestArea = 0;
        
        for (Rectangle r : list)
        {
            double height = r.getHeight();
            double width = r.getWidth();
            double area = width*height;
            if (area > largestArea){
                largestArea = area;
                largest = r;
            }
        }
        return largest;
    }

    /**
     * swaps the element at index1 with the element at index2. 
     * If either index is out of bounds, do not changing anything.
     * @param index1 integer
     * @param index2 integer
     */
    public void swap(int index1, int index2)
    {
        if (index1 >= 0 && index2 >= 0 && index1 <= list.length-1 && index2 <= list.length-1)
        {
            Rectangle temp = list[index1];
            list[index1] = list[index2];
            list[index2] = temp;
        }
    }

    /**
     * gets the area of the rectangle parameter
     * @param r array list r with rectangle dimensions
     * @return area of rectangle
     */
    public double area(Rectangle r){
        return r.getWidth() * r.getHeight();
    }

    @Override
    public String toString()
    {
        return Arrays.toString(list);
    }
}
