/**
 * models a rectangular window with a semi-circle on top
 */
public class Window
{
   public static final double  COST_PER_OUNCE = 2.54;  //constant
   public static final int SQUARE_INCHES_PER_SQUARE_FOOT = 144; //constant
   public final static int SQUARE_INCHES_PER_OUNCE_OF_GLAZE = 10; //constant
   
   private double width;
   private double height;
   
   /**
    * constructs window with x width and y height
    * @param width width of window
    * @param height height of window
    */
   public Window (double width, double height){
       this.width = width;
       this.height = height;
   }
  
   /**
    * Gets the width of this Window
    * @return the width of the Window
    */
   public double getWidth()
   {
       return width;    
   }
   
   /**
    * Gets the height of this Window
    * @return the height of the Window
    */
   public double getHeight()
   {
       return height;
   }
   
   /**
    * sets a new width and height for the window
    * @param theWidth new width
    * @param theHeight new height
    */
   public void setDimensions(double theWidth, double theHeight) {
       this.width = theWidth;
       this.height = theHeight;
   }
   
   /**
    * Gets the area of the window
    * @return area of the window
    */
   public double getArea(){
       double widthInInches = width*12;
       double heightInInches = height*12;
       double radiusCircle = (double)widthInInches/2; //width of the rectangle = diameter of the semi-circle
       return widthInInches * heightInInches + ((Math.PI * Math.pow(radiusCircle, 2))/2);
   }
   
   /**
    * Gets the cost of the glaze needed for this window
    * @return cost of the glaze for window
    */ 
   public double getCostOfGlaze(){
       
       double area = getArea();
       return (area / SQUARE_INCHES_PER_OUNCE_OF_GLAZE) * COST_PER_OUNCE;
  
   }
}
