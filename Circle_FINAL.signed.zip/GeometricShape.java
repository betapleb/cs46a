public interface GeometricShape
{
    double area(); 
}
