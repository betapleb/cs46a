/**
 * models a person's initials
 */
public class Monogram
{
    // instance variables - replace the example below with your own
    private String firstName;
    private String middleInitial;
    private String lastName;

    /**
     * initializes the instance variables with the values of the parameters
     * @param theFirst first name
     * @param theMiddleInitial middle initial
     * @param theLast last name
     */
    public Monogram(String theFirst, String theMiddleInitial, String theLast){
        firstName = theFirst;
        middleInitial = theMiddleInitial.substring(0, 1);
        lastName = theLast;
    }
    
    /**
     * initializes the first and last names to the given parameters
     * @param theFirst first name
     * @param theLast last name
     */
    public Monogram(String theFirst, String theLast){
        firstName = theFirst;
        lastName = theLast;
        middleInitial = "";
    }
    
    /**
    * Gets the first name
    * @return first name
    */
    public String getFirstName(){
        return firstName;
    }
    
    /**
    * Gets the middle initial 
    * @return middle initial
    */
    public String getMiddleInitial(){
        return middleInitial;
    }
    
    /**
    * Gets the last name
    * @return last name
    */
    public String getLastName(){
        return lastName;
    }
    
    
    /**
    * Gets the full name
    * @return full name
    */
    public String getName(){
        //return null;
        return firstName + " " + middleInitial + " " + lastName;
    }
    
    
    /**
    * Gets the initials of full name
    * @return initials of full name
    */    
    public String getMonogram(){
        //return null;
        return firstName.substring(0,1) + middleInitial + lastName.substring(0,1);
    }
}
