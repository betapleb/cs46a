import java.util.ArrayList;
/**
 * static methods to work with arrays and ArrayLists
 */
public class StaticPractice
{
    /**
     * gets the maximum value in the array.
     * @param numbers array
     * @return maximum value in the array
     */
    public static int max(int[] numbers)
    {
        int max = numbers[0];
        for (int p : numbers){
            if (p > max){
                max = p;
            }
        }
        return max;
    }
    
    /**
     * Gets the maximum value in the ArrayList as an int.
     * @param numbers arraylist
     * @return maximum value in the arraylist
     */
    public static int max(ArrayList<Integer> numbers){
        int max = numbers.get(0);
        for (int p : numbers){
            if (p > max){
                max = p;
            }
        }
        return max;
    }
    
    
    /**
     * determines if the target is in the array at least two times. 
     * @param list integer array
     * @param target number
     * @return true if it is, otherwise returns false
     */
    public static boolean containsTwice(int[] list, int target){
        boolean exists = false;
        int counter = 0;
        for (int p : list){
            if (p == target){
                counter++;
                if (counter == 2){
                    exists = true;
                }
            }
        }
        return exists;
    }
    
    /**
     * determines if the target is in the ArrayList at least two times.
     * @param list integer arraylist
     * @param target number
     * @return true if it is, otherwise returns false
     */
    public static boolean containsTwice(ArrayList<Integer> list, int target){
        boolean exists = false;
        int counter = 0;
        for (int p : list){
            if (p == target){
                counter++;
                if (counter == 2){
                    exists = true;
                }
            }
        }
        return exists;       
    }
    
}
