public class StringsRUs
{
//IGNORECASE false
   public static void main(String[] args)
   {
       String word = "separate";
       int wordLen = word.length();
       System.out.println(wordLen*2);
       String upper = word.toUpperCase();
       System.out.println(upper);
       String replaced1 = word.replace("t", "7");
       String replaced2 = replaced1.replace("a","4");
       String replaced3 = replaced2.replace("e","3");
       System.out.println(replaced3);
       System.out.println(word);
       
       
   }
}
