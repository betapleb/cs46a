/**
 * Interacts with user entered name.
 */
import java.util.Scanner;
public class IfPractice {
    public static void main (String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter your full name: ");
        String fullName = in.nextLine();
        System.out.println("Hello, " + fullName + "!");
       
        String jNickname = "Jim";
        String rNickname = "Bobby";
        String aNickname = "Ash";
        String oNickname = "Buddy";
        
        String firstName;
        
        if (fullName.indexOf(" ") > -1) {
            firstName = fullName.substring(0, fullName.indexOf(" "));
        } else {
            firstName = fullName;
        }
        
        
        if (firstName.equals("James") || firstName.equals("james")){
            firstName = jNickname;
            System.out.println("I think I will call you " + firstName);
        } else if (firstName.equals("Robert") || firstName.equals("robert")){
            firstName = rNickname;
            System.out.println("I think I will call you " + firstName);
        } else if (firstName.equals("Ashwani") || firstName.equals("ashwani")){
            firstName = aNickname;
            System.out.println("I think I will call you " + firstName);
        } else {
            firstName = oNickname;
            System.out.println("I think I will call you " + firstName);
        }
        
            
        System.out.print("How old are you? ");
        int age = in.nextInt();
        
        if (age>=0 & age<18) {
            System.out.println("You are a child, " + firstName);
        } else if (age>=18 & age<21) {
            System.out.println("You can vote, but you can not drink, " + firstName);
        } else if (age>=21 & age<65) {
            System.out.println("You are a full adult, " + firstName);
        } else {
            System.out.println("You can get social security, " + firstName);
        }
        System.out.println("Goodbye, " + fullName + "!");
        
    }
}
