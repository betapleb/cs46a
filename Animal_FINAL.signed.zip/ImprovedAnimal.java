
/**
 * has a cap on the amount of energy an animal can have. 
 */
public class ImprovedAnimal extends Animal
{
    private int maxEnergy;

    /**
     * takes a parameter that sets a maximum for energy. 
     * If the amount the ImprovedAnimal eats would set its energy above the max, 
     * the energy level is only increased to the max.
     * @param maxEnergy amount of energy
     */
    public ImprovedAnimal(int maxEnergy)
    {
        this.energy = 0;
        this.maxEnergy = maxEnergy;
    }

    /**
     * increases the amount of energy the animal has by amount, but only if amount > 0
     * @param  amount of energy
     */
    public void eat(int amount)
    {
        if (amount > 0){
            this.energy = this.energy + amount;
            if(energy > maxEnergy){
                this.energy = maxEnergy;
            }
            else {
                this.energy = energy;
            }
        }
    }
}
