/**
 * life of an animal
 */
public class Animal
{

    public int energy;

    /**
     * Constructor for objects of class Animal
     */
    public Animal()
    {
        energy = 0;
    }

    /**
     * which increases the amount of energy the animal has by amount, but only if amount > 0
     * @param  amount of energy
     */
    public void eat(int amount)
    {
        if (amount > 0){
            energy+= amount;
        }
    }

    /**
     * which decreases the amount of energy the animal has by amount. 
     * Energy changes only if amount > 0. 
     * The energy can never be less than 0. 
     * If an Animal has an energy of 2 and tries to move 5, its energy will be 0.
     * @param  amount of energy
     */
    public void move(int amount){
        if (amount > 0){
            if (energy - amount >= 0)
            {
                energy = energy - amount;
            }
            else {
                energy = 0;
            }

        }
    }

    /**
     * returns the amount of energy the animal has left
     * @return amount of energy the animal has left
     */
    public int getEnergy()
    {
        return energy;
    }

}
