public class SnowmanDrawing {
 
    public static void main (String[] args) {
        
        Rectangle hat = new Rectangle(50, 10, 20, 20);
        hat.fill();
        Line brim = new Line(40, 30, 80, 30); //x,y of starting and x.y of ending. 
        brim.draw();
        Ellipse smCircle = new Ellipse(50, 30, 20, 20); //leftmost x coord, topmost y coord, width of box, height of box.
        Ellipse mdCircle = new Ellipse(40, 50, 40, 40);
        Ellipse lgCircle = new Ellipse(30, 90, 60, 60);
        smCircle.draw();
        mdCircle.draw();
        lgCircle.draw();
        
        
    }
    
}