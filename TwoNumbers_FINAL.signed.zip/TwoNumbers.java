import java.util.Scanner;
/**
 * ask the user for two numbers and print out comments based on their values
 */
public class TwoNumbers
{
   
    public static void main (String[] args) {
        System.out.print("Enter two numbers (like this: 41.7 -22.5): ");
        Scanner in = new Scanner(System.in);
        double num1 = in.nextDouble();
        double num2 = in.nextDouble();
        
        if (num1 == num2) 
        {
            System.out.println("The first number is equal to the second");
        }   
        else {
            if (num1 > num2) 
            {
                System.out.println("The first number is greater than second");
                if (num1-num2<=0.0001) {
                    System.out.println("The numbers are close together");
                }
                else if (num1-num2>=10000) {
                    System.out.println("The numbers are far apart");
                }
            } else{
                System.out.println("The first number is less than second");
                if (num2-num1<=0.0001){
                    System.out.println("The numbers are close together");
                }
                else if (num2-num1>=10000){
                    System.out.println("The numbers are far apart");
                }
                
                
            }
            
            if ((num1<0 && num2>0) || (num1>0 && num2<0)) 
            {
                System.out.println("The numbers have different signs");
            }   
            else 
            {
                System.out.println("The numbers have the same sign");
            }
        }
    }
}
