public class ArrayRectangleManager
{
    private Rectangle[] boxes;

    public ArrayRectangleManager(Rectangle[] array)
    {
        boxes = array;
    }

    public Rectangle maxWidth(){
        Rectangle largest = boxes[0];
        if(boxes.length == 0){
            return null;
        } else {
            for(Rectangle r : boxes){
                if (r.getWidth() > largest.getWidth()){
                    largest = r;
                }
            }
        }
        return largest;
    }
}
