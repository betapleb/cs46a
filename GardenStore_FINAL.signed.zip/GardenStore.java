import java.util.ArrayList;
/**
 * manages a garden
 */
public class GardenStore
{

    private ArrayList<Plant> store;

    /**
     * Constructor for objects of class GardenStore
     */
    public GardenStore()
    {
        store = new ArrayList<Plant>();
    } 

    /**
     * Adds the specified Plant to the GardenStore
     * @param name of plant
     */
    public void add(Plant name){
        store.add(name);
    }

    /**
     * Finds the total cost of all  Plants in the GardenStore
     * @return sum total
     */
    public double sum(){
        double sum = 0;
        for(Plant p : store){
            sum += p.getPrice();
        }
        return sum;
    }

    /**
     * determines if a Plant with a given name is in the GardenStore
     * @param target name of plant to check
     * @return true if a Plant with that name is in the GardenStore. Otherwise false.
     */
    public boolean contains(String target){
        boolean exists = false;
        for (Plant p : store){
            if (target.equals(p.getName()))
            {
                exists = true;
            }
        }
        return exists;
    }

    /**
     * gets an ArrayList<String> containing the names of the Plants  in the GardenStore.
     * @return plantNames arraylist of plants
     */
    public ArrayList<String> plantList()
    {
        ArrayList<String> plantNames = new ArrayList<String>();
        for (Plant p : store)
        {
            plantNames.add(p.getName());
        }
        return plantNames;
    }
}
