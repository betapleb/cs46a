/**
 * adding plant name and price
 */
public class Plant
{
    // instance variables 
    private double price;
    private String name;

    /**
     * changes name
     * @param newName the name to change to
     */
    public void setName(String newName){
        name = newName;
    }

    /**
     * changes price
     * @param newPrice the price to change to
     */
    public void setPrice(double newPrice){
        price = newPrice;
    }

    /**
     * provides name of plant
     * @return name of plant
     */
    public String getName(){
        return name;
    }

    /**
     * provides price of plant
     * @return price of plant
     */
    public double getPrice(){
        return price;
    }

    /**
     * takes name and price of a plant
     * @param name of plant
     * @param price of plant
     */
    public Plant(String name, double price)
    {
        this.name = name;
        this.price = price;
    }

}
