import java.util.Scanner;

public class SeaLevelProcessor
{
    public static void main (String args[]){
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the sea level or Q to quit: ");
        int above = 0;
        double highest = 0;
        int count = 0;
        double sum = 0;
        if (!in.hasNextInt()){
            System.out.print("No values entered");
        } else {
            while (in.hasNextInt())
            {   
                double seaLevel = in.nextInt();
                System.out.print("Enter the sea level or Q to quit: ");
                if (seaLevel > 0){
                    above++;
                }
                if (seaLevel > highest){
                    highest = seaLevel;
                } else if (seaLevel < 0){
                    highest = seaLevel;
                }
                sum = sum + seaLevel;
                count++;
            }
            System.out.println(above);
            System.out.println(highest);
            System.out.println(sum/count);
        }
    }
}
