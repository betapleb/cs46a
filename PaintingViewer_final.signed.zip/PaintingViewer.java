/**
 * Enlarges an image of a painting
 * 
 * @author Jennifer Quach
 */
public class PaintingViewer
{
    public static void main(String[] args)
    {
        Picture starry_night = new Picture("starry_night.png");
        starry_night.translate(100, 50);
        starry_night.grow(53,43);
        starry_night.draw();
    }
}