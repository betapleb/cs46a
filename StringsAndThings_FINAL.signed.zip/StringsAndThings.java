/**
 * does things with strings
 */

public class StringsAndThings
{
    // instance variables 
    private String things;

    /**
     * constructs a string
     * @param things sentence
     */
    public StringsAndThings(String things)
    {
        // initialise instance variables
        this.things = things;
    }

    /**
     * count how many of the characters in the string are not letters
     * @return count of non letters
     */
    public int countNonLetters()
    {
        int total = 0;
        for (int i = 0; i < things.length(); i++){
            char ch = things.charAt(i);
            if (!Character.isLetter(ch)){
                total++;
            }
        }
        return total;
    }
    
    
    /**
     * checks if letter is a vowel
     * @param letter string of length 1
     * @return true if letter is vowel
     */
    public boolean isVowel(String letter)
    {
        letter = letter.toLowerCase();
        return (things.length()<=1 && letter.contains("a")||letter.contains("e")||letter.contains("i")||letter.contains("o")||letter.contains("u")||letter.contains("y"));
    }
        

    /**
     * returns true if the String parameter has more vowels than consonants. 
     * Otherwise it returns false. 
     * @return boolean value if string has more vowels than consonants.
     */
    public boolean moreVowels()
    {
        int numConsonants = 0;
        int numVowels = 0;
        for (int i = 0; i < things.length(); i++){
            char ch = things.charAt(i);
            String letter = things.substring(i, i+1);
            if (Character.isLetter(ch)){
                if (isVowel(letter)){
                    numVowels++;
                } else {
                    numConsonants++;
                }   
            }
        }
        if (numVowels > numConsonants)
        {
            return true;
        } else {
            return false;
        }
    }

    /**
     * removes duplicates from strings.
     * @returns a string where each character in the phrase appears exactly once
     * public String noDuplicates 
     */
    public String noDuplicates()
    {   
        String newSentence = "";
        boolean dup = false;
        int i = 0;
        while (i < things.length())
        {
            String firstLetter = things.substring(0, 1);
            newSentence += firstLetter;
            for (i = 0; i < things.length(); i++){
                String letter = things.substring(i, i+1);
                if (!newSentence.contains(letter)){
                    newSentence += letter;
                }
            }   
        }
        return newSentence;

    }

}
