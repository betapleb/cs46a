/**
 * Models a computer with a brand and a clock speed 
 * in gigahertz 
 */
public class Computer implements Comparable
{
    private String brand;
    private double ghz;

    /**
     * models a Computer
     * @param brand name of computer
     * @param ghz computer clock speed
     */
    public Computer(String brand, double ghz){
        this.brand = brand;
        this.ghz = ghz;
    }
    
    /**
     * compares brand and ghz of Computers
     * @param otherObject ghz of computers
     */
    public int compareTo(Object otherObject){
        Computer otherComp = (Computer) otherObject; //cast
        if(this.equals(otherComp)){
            return 0;
        } else if (this.ghz < otherComp.getGhz()){
            return -1;
        } else if (this.ghz > otherComp.getGhz()){
            return 1;
        } else {
            return this.brand.compareTo(otherComp.brand);
        }
    } 

    /**
     * gets Gigahertz: a measure of the clock speed of a computer.
     * @return ghz computer speed
     */
    public double getGhz(){
        return ghz;
    }

    /**
     * gets String brand of computer
     * @return brand computer name
     */
    public String getBrand(){
        return brand;
    }

    /**
     * Gets a string representation of the object
     * @return a string representation of the object
     */
    public String toString()
    {
        String s = getClass().getName()
            + "[brand=" + brand
            + ",gigahertz=" + ghz 
            + "]";
        return s;
    }
}
