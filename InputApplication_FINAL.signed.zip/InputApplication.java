/**
 * Takes in user input and gives output based on input.
 */
import java.util.Scanner;

public class InputApplication {
    public static void main(String[] args) {
        Scanner myScanner = new Scanner(System.in);
        System.out.print("Enter a word: ");
        String word1 = myScanner.next();
        System.out.println(word1.substring(word1.length()-1));
       
        System.out.print("Enter a double: ");
        double numDecimal = myScanner.nextDouble();
        System.out.print("Enter an integer: ");
        int numInteger = myScanner.nextInt();
        double product = numInteger * numDecimal;
        System.out.println("Product: " + product);
        System.out.println("Integer portion: " + (int)product);
        
        
    }
}
