/**
   models a grocery bill to which the cost of 
   items can be added and removed
*/
public class GroceryBill
{
    private double itemCost; // unnecessary instance var. 
    private double subTotal;
    /**
     * Initializes subTotal of grocery bill to 0.
     */
    public GroceryBill()
    {
        subTotal = 0;
    }
    /**
     * Adds amount to subtotal
     * @param amount of item to add to total
     */
    public void add(double amount){
        if (amount > 0) {
            subTotal = amount + subTotal;
        }
        
    }
    /**
     * Subtracts amount from subtotal
     * @param amount of item to subtract from total
     */
    public void remove(double amount){
        if (amount > 0 && amount <= subTotal){
            subTotal = subTotal - amount;
        }
        
    }
    /**
     * Get the subtotal 
     * @return total amount
     */
    public double getSubtotal(){
        return subTotal;
    }
    
}
