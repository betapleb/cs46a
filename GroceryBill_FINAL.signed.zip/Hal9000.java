/**
 * Hal9000 simulate an AI that interacts with the crew
 * of a space ship.
 * 
 */
public class Hal9000
{
    private String name;
    /**
     * creates a crewmember with a name
     * @param crewName string name of a crewmember
     */
    public Hal9000(String crewName){
        if (crewName.length() <= 8){
            name = crewName;
        } else if (crewName.length() > 8){
            name = crewName.substring(0, 8);
        }
        if (name.equals("Robert")) {
            name = "Bob";
        }

        
    }
    /**
     * retrieves the name of crewmember
     * @return name of crewmember
     */
    public String getName(){
        return name;
    }
    /**
     * changes crewmember's name to a new one
     * @param newName the new name to be changed to
     */
    public void setName(String newName){
        if (newName.length() <= 8){
            name = newName;
        } else if (newName.length() > 8){
            name = newName.substring(0, 8);
        }
        if (name.equals("Robert")) {
            name = "Bob";
        }
        
    }
    /**
     * greets crewmember by name
     * @return a string that welcomes crewmember
     */
    public String greetCrewMember(){
        //return null;
        return ("Welcome, " + name);
    }
    /**
     * tells crewmember they are unable to do what's ask
     * @param whatToDo tells Hal what to do
     * @return a string that says addresses crewmember by name and says they cannot do what is asked.
     */
    public String doCommand(String whatToDo){
        //return null;
        return ("I am sorry, " + name + "." + " I can't " + whatToDo);
    
    }
}
