import java.util.Random;
/**
 * Draws random squares
 */
public class RandomSquares
{
    public static void main(String[] args)
    {
        //generate random values in given order: x coord, y coord, length. 
        final int MAX_X = 200;
        final int MAX_Y = 300;
        Random gen = new Random(987456789);
        final int MAX_LENGTH = 80; //LENGTH 100 EXCLUSIVE
        final int MIN_LENGTH = 20; //LENGTH 20 INCLUSIVE
        final int NUM_OF_SQUARES = 25;

        int length = 0;
        int largest = 0;
        Rectangle bigSquare = null;
        for(int i = 0; i < NUM_OF_SQUARES; i++)
        {   

            int xCoord = gen.nextInt(MAX_X);
            int yCoord = gen.nextInt(MAX_Y);
            //length random value between 20 (inclusive) & 100 (exclusive). 
            length = MIN_LENGTH + gen.nextInt(MAX_LENGTH); //80 we're adding 20 everytime. 

            Rectangle square = new Rectangle(xCoord, yCoord, length, length);
            square.setColor(Color.GREEN);
            square.draw();

            if (length > largest)
            {
                largest = length;
                bigSquare = square;
            }
        }

        //Rectangle bigSquare = new Rectangle(xOfLargest, yOfLargest, largest, largest);
        bigSquare.setColor(Color.BLUE);
        bigSquare.fill();

    }
}