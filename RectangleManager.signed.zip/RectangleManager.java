import java.util.ArrayList;
public class RectangleManager
{
    private ArrayList<Rectangle> boxes;

    public RectangleManager()
    {
        boxes = new ArrayList<>();
    }

    public void add(Rectangle r)
    {
        boxes.add(r);
    }

    public Rectangle maxWidth(){
        if (boxes.isEmpty()){
            return null;
        } else {
            Rectangle largest = boxes.get(0); 
            //int maxWidth = 0;
            for(Rectangle r: boxes)  
            {
                
                if(r.getWidth() > largest.getWidth())
                {
                    largest = r;
                }
            }
            return largest;
        }
    }
}
