import java.util.ArrayList;
import java.awt.Point;

public class PointsGalore
{
    // instance variables - replace the example below with your own
    private ArrayList<Point> points;
    private static final int DIAMETER = 3;

    public PointsGalore(ArrayList<Point> list)
    {
        // initialise instance variables
        points = list;
    } 

    public void drawRectangle()
    {
        final double WIDTH = getMaxX()-getMinX();
        final double HEIGHT = getMaxY()-getMinY();
        drawPoints();
        Rectangle rec = new Rectangle(getMinX(), getMinY(), WIDTH, HEIGHT);
        rec.draw();
        
        /** draft: draw a rectangle whose upper left-hand corner is 
         * at the coordinates of the Point at index 0 and which has 
         * a width of 50 and a height of 30.
         * 
        final int WIDTH = 50;
        final int HEIGHT = 30;
        drawPoints();
        int i = 0;
        Rectangle rec = new Rectangle(getMinX(), getMinY(), getMinX(), HEIGHT);
        rec.draw();
        
         */

    }

    public void drawPoints()
    {
        for (Point p : points)
        {
            double x = p.getX();
            double y = p.getY();
            Ellipse circle = new Ellipse (x, y, DIAMETER, DIAMETER);
            circle.fill();
        }
    }

    public double getMinX(){
        double minX = points.get(0).getX();
        for(int i=0; i < points.size(); i++)
        {
            if((points.get(i)).getX()<minX)
            {
                minX= points.get(i).getX();
            }
        }
        return minX;
    }

    public double getMinY(){
        double minY = points.get(0).getY();
        for(int i=0; i < points.size(); i++)
        {
            if((points.get(i)).getY() < minY)
            {
                minY= points.get(i).getY();
            }
        }
        return minY;
    }

    public double getMaxX(){
        double maxX = points.get(0).getX();
        for(int i=0; i < points.size(); i++)
        {
            if((points.get(i)).getX() > maxX)
            {
                maxX= points.get(i).getX();
            }
        }
        return maxX;
    }

    public double getMaxY(){
        double maxY = points.get(0).getY();
        for(int i=0; i < points.size(); i++)
        {
            if((points.get(i)).getY() > maxY)
            {
                maxY= points.get(i).getY();
            }
        }
        return maxY;
    }
}

