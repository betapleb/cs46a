
public class IntArray2DProcessorTester
{
    public static void main(String[] args)
    {
        int[][] array = {
                {1,2,3,-5},
                {3,5,-1,2},
                {-2,7,5,3}
            };
        IntArray2DProcessor processor = new IntArray2DProcessor(array);
        
        System.out.println(processor.sum());
//         System.out.println(processor.max());
//         System.out.println(processor.sum(1));
        
    }
}
