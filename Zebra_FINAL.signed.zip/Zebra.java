/**
 * Zebra states
 */
public class Zebra
{

    public static final int NOT_HUNGRY = 1;
    public static final int SOMEWHAT_HUNGRY = 2;
    public static final int HUNGRY = 3;
    public static final int VERY_HUNGRY = 4;
    public int state = VERY_HUNGRY;

    /**
     * must initialize the state to VERY_HUNGRY.
     */
    public Zebra()
    {
        this.state = state;
    }

    /**
     * Gets the integer representing the state, an integer 1 through 4.
     * @return state of zebra
     */
    public int getState()
    {
        return state;
    }

    /**
     * the Zebra becomes more hungry if not already VERY_HUNGRY
     */
    public void run(){
        if (state < VERY_HUNGRY){
            state += 1;
        }
    }

    /**
     * the Zebra will eat if it is hungry and become less hungry
     */
    public void seeFood(){
        if (state >= 2){
            state -= 1;
        }
    }

    /**
     * Gets a string describing the current hunger state of the Zebra: 
     * "Not hungry", "Somewhat hungry ,"Hungry", or "Very hungry"
     * @return state of zebra
     */
    public String getHungerLevel(){
        String zebraState = "";
        if (state == 1){
            zebraState = "Not hungry";
        } else if (state == 2){
            zebraState = "Somewhat hungry";
        } else if (state == 3){
            zebraState = "Hungry";
        } else {
            zebraState = "Very hungry";
        }
        return zebraState;
    }

}
