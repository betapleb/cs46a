
/**
 * models a snowman at a given (x,y) coordinate and can draw itself. 
 */
public class Snowman
{
    // instance variables - replace the example below with your own
    private int x;
    private int y;

    /**
     * takes the x and y coordinates of the upper left hand corner of the rectangular part of the hat
     * @param xCoord the x coordinate of where to begin drawing
     * @param yCoord the y coordinate of where to begin drawing
     */
    public Snowman(int xCoord, int yCoord)
    {
        x = xCoord;
        y = yCoord;
    }

    /**
     * draws a hat with a brim, and 3 circles for a snowman.
     */
    public void draw()
    {
        Rectangle hat = new Rectangle(x, y, 20, 20);
        hat.fill();
        Line brim = new Line(x-10, y+20, x+30, y+20); //x,y of starting and x.y of ending. 
        brim.draw();
        
        Ellipse smCircle = new Ellipse(x, y+20, 20, 20); //leftmost x coord, topmost y coord, width of box, height of box.
        Ellipse mdCircle = new Ellipse(x-10, y+40, 40, 40);
        Ellipse lgCircle = new Ellipse(x-20, y+80, 60, 60);
        smCircle.draw();
        mdCircle.draw();
        lgCircle.draw();
        
    }
}
