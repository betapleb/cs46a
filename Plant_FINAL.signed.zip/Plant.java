/**
 * adding plant name and price
 */
public class Plant implements Comparable
{
    // instance variables 
    private double price;
    private String name;

    public int compareTo(Object otherObject){
        Plant otherPlant = (Plant) otherObject; //cast
        if(this.equals(otherPlant)){
            return 0;
        } else if (price < otherPlant.getPrice()){
            return -1;
        } else if (price > otherPlant.getPrice()){
            return 1;
        } else {
            return name.compareTo(otherPlant.getName());
        }
    } 

    /**
     * changes name
     * @param newName the name to change to
     */
    public void setName(String newName){
        name = newName;
    }

    /**
     * changes price
     * @param newPrice the price to change to
     */
    public void setPrice(double newPrice){
        price = newPrice;
    }

    /**
     * provides name of plant
     * @return name of plant
     */
    public String getName(){
        return name;
    }

    /**
     * provides price of plant
     * @return price of plant
     */
    public double getPrice(){
        return price;
    }

    /**
     * takes name and price of a plant
     * @param name of plant
     * @param price of plant
     */
    public Plant(String name, double price)
    {
        this.name = name;
        this.price = price;
    }

}
