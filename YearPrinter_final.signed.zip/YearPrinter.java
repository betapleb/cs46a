/**
 * Write a description of class YearPrinter here.
 *
 * @author Jennifer Quach
 * @version 1b
 */
public class YearPrinter
{
    public static void main (String[] args)
    {
        System.out.println("|*YEAR**|");
        System.out.println("|*2017**|");
        System.out.println("|*\u216F\u216F\u2169\u2166*|");
        System.out.println("|*******|");
    }
}