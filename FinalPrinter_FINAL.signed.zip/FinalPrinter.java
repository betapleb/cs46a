/**
 * Prints how many days until the first day of finals
 * @author Jennifer Quach
 */
public class FinalPrinter
{
    public static void main(String[] args)
    {
      
        //leave this line
        Day today = new Day();
        Day firstDayFinal = new Day(2017, 12, 13);
        System.out.println("Today is " + today.toString());
        System.out.println(firstDayFinal.daysFrom(today));
        
        
        today.addDays(100);
       
        System.out.println(today.getYear());
        System.out.println(today.getMonth());
        System.out.println(today.getDayOfMonth());
        
    }
}
