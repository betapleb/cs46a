import java.util.ArrayList;
/**
 * Write a description of class PracticeWithArrayLists here.
 * array list practice
 */
public class PracticeWithArrayLists
{
    public static void main (String [] args){
        ArrayList<String> zoo = new ArrayList<String>();
        zoo.add("tiger");
        zoo.add("lion");
        zoo.add("elephant");
        zoo.add("kangaroo");
        
        
        zoo.set(1, "giraffe");
        
        
        
        int lastIndex = zoo.size()-1;
        zoo.set(lastIndex-1, "wallaby");
        zoo.set(lastIndex, "zebra");
        
        zoo.remove("lion");
        System.out.println(zoo.get(0)+"***");
        System.out.println(zoo);
        for (String z: zoo){
            System.out.println(z);
        }
        
        
    }
    
}
