import java.util.Scanner;
public class FunWithLoops {
	public int sumOdd(int value) {
		if (value <= 0) {
			return 0;
		}
		int sum = 0;
		for (int i = 0; i <= value; i+=2) {
			sum = sum+i;
		}
		return sum;
	}
	
	public double average(int count) {
		if (count <= 0) {
			return 0;
		}
		double total = 0;
		for (int i = 1; i <= count; i++) {
			System.out.print("Enter integer " + i + ": ");
			Scanner in = new Scanner(System.in);
			int num = in.nextInt();
			total = total + num;
		}
		return total/count;
	}
	
	public double sumSeries(int value) {
		double val = value;
		double summation = 0;
		double num = 0;
		if (val == 0 || val % 2 == 0) {
			return 0.0;
		} else if (val==1) {
			return 1;
		}
		for (int i = value; i > 1; i=i-2) {
			num = (i-2.0)/i;
			summation = num + summation;
		}
		return summation+1;
	}
}
